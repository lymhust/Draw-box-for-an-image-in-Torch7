draw = require 'draw'
require 'image'
image.display(draw.drawBox(image.lena(), 0.5, 0.5, 0.9, 0.9, 5, {0.3,1,0.7}))
