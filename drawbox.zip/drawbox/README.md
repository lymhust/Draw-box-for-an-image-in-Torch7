examplepackage.torch
====================

A hello-world for torch packages

You can install the package by opening a terminal, changing directory into the folder and typing:

luarocks make
